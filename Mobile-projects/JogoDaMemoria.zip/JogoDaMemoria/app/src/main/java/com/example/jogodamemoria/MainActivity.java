package com.example.jogodamemoria;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Vetor para salvar todos os botoes do jogo.
    Button[] buttons = new Button[16];

    // Vetor para salvar os botoes pressionados.
    Button[] botoesPressionados = new Button[2];

    // Vetor para salvar o numero dos dois botoes pressionados.
    int[] numBotoesPressionados = {-1, -1};

    // Vetor para salvar o numero interno de cada botao.
    int[] ordem = new int[16];

    // Reiniciar o jogo.
    Button botaoResetar;

    // TextView que mostra as vidas do jogador.
    TextView txtVidas;

    // TextView que mostra o status do jogo (se o jogador ganhou ou perdeu)
    TextView txtStatus;

    // Temp                         : É usada para determinar a posicao no vetor 'botoesPressionados'
    // Vidas                        : Quantidade de vidas do jogador. Se chegar a 0, o jogador perdeu.
    // vitoriasParciais             : Quantidade de vitoria parciais do jogador. Se chegar a 8, o jogador ganhou.
    // contadorDeBotaoPressionado   : Guarda quantos botoes foram pressionados. Usado para identificar quando acaba a 'vez' do jogador.

    int temp=0;
    int vidas=8;
    int vitoriasParciais=0;
    int contadorDeBotaoPressionado=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoResetar    = findViewById(R.id.btnResetar);
        txtVidas        = findViewById(R.id.vidas);
        txtStatus       = findViewById(R.id.status);

        carregarVidas();

        carregarBotoes();
    }

    protected void carregarBotoes() {

        // qtdQuadros       : Quantos qudrados tem no jogo.

        // numerosSortados  : Vetor que armazena os numeros que são sorteados para que esses não
        // sejam sorteados novamente.

        int qtdQuadros = 16;
        int[] numerosSorteados = new int[16];

        for (int a = 1; a <= qtdQuadros; a++) {

            int random;

            while (true) {

                // Sortar um numero de 1 a 16
                random = new Random().nextInt(16) + 1;
                int flag=0;

                // Verificar se esse numero ja foi sorteado
                for (int b=0; b < a; b++) {
                    if (numerosSorteados[b] == random) {

                        // Valor é repetido
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0) {break;}
            }

            //Log.d("RANDOM", String.valueOf(random));

            // Armazenar o valor sorteado no vetor.
            numerosSorteados[a-1] = random;

            // Guadar em uma variavel o nome do botão a ser buscado.
            String botao = "btn" + random;

            // Pegar o valor de ID dessa variavel.
            int botaoID = getResources().getIdentifier(botao, "id", getPackageName());

            // Utilizar do ID para achar o botão em questão dentro do layout e guarda-lo no vetor.
            buttons[a-1] = (Button) findViewById(botaoID);

            // Adicionar um numero nesse botao

            // Esse numero será referente a variavel 'a' e caso essa seja > 8, ela será dividida em 2
            // para garantir que sempre tenha dois numeros iguais nos botões do jogo.

            int k = a;
            if (a > (qtdQuadros/2)) {
                k = (k - (qtdQuadros/2));
            }

            // buttons[a-1].setText(String.valueOf(k));
            ordem[random-1] = k;

            //Adicionar o evento de 'click' no botão.
            buttons[a-1].setOnClickListener(this);
        }

        // Configurando o botão de resetar
        botaoResetar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Resetar Status para cor de texto branca e o seu texto para 'STATUS'
                txtStatus.setTextColor(Color.parseColor("#FFFFFF"));
                txtStatus.setText("STATUS");

                // Resetar vidas e vitoriasParciais
                vidas=8;
                vitoriasParciais=0;

                // Atualizar as vidas no layout
                carregarVidas();

                // Carregar novos numeros para os botões
                carregarBotoes();

                // Resetar nos botões:
                //  -> cor de fundo para branco novamente.
                //  -> torna-los 'clicaveis' novamente.
                //  -> deixa-los com seus textos invisiveis.

                for (int a=0; a<16; a++) {
                    buttons[a].setBackgroundColor(buttons[a].getContext().getResources().getColor(R.color.white));
                    buttons[a].setEnabled(true);
                    buttons[a].setText("");
                }
            }
        });
    }

    public void onClick(View v) {

        contadorDeBotaoPressionado++;

        if (contadorDeBotaoPressionado == 3) {
            // Dois botoes incorretos foram pressionados previamente, portanto:
            // -> Resetar seus conteudos
            // -> Resetar vetor de botoesPressionados

            botoesPressionados[0].setText("");
            botoesPressionados[1].setText("");

            botoesPressionados = new Button[2];

            contadorDeBotaoPressionado = 1;
        }

        // Armazenar o botao na variavel 'b'
        Button b = (Button) v;

        // Pegar o id numérico do botao
        int idNumericoBotaoPressionado = v.getId();

        // Pegar o nome id do botao baseado no id numérico. (ex: btn1, btn2 ...)
        String idBotaoPressionado = getResources().getResourceEntryName(idNumericoBotaoPressionado);
        Log.d("idBotaoPressionado", idBotaoPressionado);

        // Pegar o numero no nome de id do botao. (ex: btn1 -> '1' , btn2 -> '2' ...)
        int numIdBotao = Integer.parseInt(idBotaoPressionado.replace("btn", ""));
        Log.d("numIdBotao", String.valueOf(numIdBotao));

        // Ir no vetor de ordem e pegar o numero referente ao botao cujo id seja 'btn' + numIdBotao
        int numInternoBtn = ordem[numIdBotao-1];

        // Mudar a cor do botao para simbolizar que foi pressionado
        b.setBackgroundColor(b.getContext().getResources().getColor(R.color.purple_200));

        // Tornar o texto do botao visivel novamente
        b.setText(String.valueOf(numInternoBtn));

        // Guardar o botao no vetor: botoesPressionados
        botoesPressionados[temp] = b;
        if (temp == 0) {
            temp = 1;
        } else {
            temp = 0;
        }

        // Guardar o numero do botao que foi pressionado no vetor: numBotoesPressionados
        for (int a=0; a<2; a++) {
            if (numBotoesPressionados[a] == -1) {
                numBotoesPressionados[a] = numInternoBtn;
                break;
            }
        }

        // Verificar se dois botoes foram pressionados (quando o vetor não possui nenhum -1)
        int flag=0;
        for (int a=0; a<2; a++) {
            if (numBotoesPressionados[a] == -1) {
                // Ainda nao
                flag = 1;
                break;
            }
        }

        // Caso dois botoes ja tenham sido pressionados
        if (flag == 0) {

            // Ja foram pressionados dois botoes, portanto verificar se sao iguais.

            // Caso sejam iguais, então houve uma vitoria parcial
            if (verificarVitoriaParcial() == 1) {

                Log.d("VitoriaParcial", "Houve!");

                // Tornar ambos os botoes 'inclicaveis'.
                botoesPressionados[0].setEnabled(false);
                botoesPressionados[1].setEnabled(false);

                vitoriasParciais++;

                // Verificar se houve vitoria TOTAL
                if (vitoriasParciais == 8) {
                    txtStatus.setTextColor(Color.parseColor("#00FF00"));
                    txtStatus.setText("VENCEU :)");
                };

                contadorDeBotaoPressionado=0;

            } else {
                // Se chegar aqui, significa que o jogador errou sua jogada

                Log.d("VitoriaParcial", "NaoHouve!");

                // Resetar a cor dos botoes para branco
                botoesPressionados[0].setBackgroundColor(b.getContext().getResources().getColor(R.color.white));
                botoesPressionados[1].setBackgroundColor(b.getContext().getResources().getColor(R.color.white));

                // Reduzir vidas
                vidas--;

                // Atualizar quantidade de vidas
                carregarVidas();

                // Verificar se variavel 'vidas' chegou a 0
                if (vidas == 0) {

                    txtStatus.setTextColor(Color.parseColor("#FF0000"));
                    txtStatus.setText("PERDEU :(");

                    // Tornar todos os botoes inclicaveis.
                    for (int a=0; a<16; a++) {
                        buttons[a].setEnabled(false);
                    }
                }

            }

            numBotoesPressionados[0] = -1; numBotoesPressionados[1] = -1;
        }
    }

    protected void carregarVidas() {
        txtVidas.setText(String.valueOf(vidas));
    }

    protected int verificarVitoriaParcial() {
        if (numBotoesPressionados[0] == numBotoesPressionados[1]) {
            return 1;
        }
        return 0;
    }

}