package com.example.projetojogodavelha;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Vetor que irá armazenar os botões presentes no layout
    Button[] buttons = new Button[9];

    // Botao de resetar o jogo e placar
    Button botaoResetar;

    // Vetor que representa o quadro do jogo
    //      0 -> Não foi pressionado
    //      1 -> Pressionado por X
    //      2 -> Pressionado por O

    int[] quadro = {0,0,0,0,0,0,0,0,0};

    // TextView dos contadores de vitória e do texto que exibe qual é o jogador atual
    TextView placarJogadorX, placarJogadorO, vezDoJogador;
    int placarX = 0;
    int placarO = 0;
    int jogadorAtual = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vezDoJogador    = (TextView) findViewById(R.id.vezJogador);
        placarJogadorX  = (TextView) findViewById(R.id.contadorX);
        placarJogadorO  = (TextView) findViewById(R.id.contadorO);
        botaoResetar    = (Button) findViewById(R.id.btnResetar);

        atualizarPlacar();
        carregarBotoes();
    }

    protected void atualizarPlacar() {
        placarJogadorX.setText(Integer.toString(placarX));
        placarJogadorO.setText(Integer.toString(placarO));

        if (jogadorAtual == 1) {
            vezDoJogador.setText("Vez do: X");
        } else {
            vezDoJogador.setText("Vez do: O");
        }
    }

    protected void carregarBotoes() {
        for (int a=0; a<9; a++) {
            // Guadar em uma variavel o nome do botão a ser buscado.
            String botao = "btn" + a;

            // Pegar o valor de ID dessa variavel.
            int botaoID = getResources().getIdentifier(botao, "id", getPackageName());

            // Utilizar do ID para achar o botão em questão dentro do layout e guarda-lo no vetor.
            buttons[a] = (Button) findViewById(botaoID);

            // Adicionar o evento de 'click' no botão
            buttons[a].setOnClickListener(this);
        }

        // Configurando o botão de resetar
        botaoResetar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarJogo();
                jogadorAtual = 1;
                placarX = 0;
                placarO = 0;
                atualizarPlacar();
            }
        });
    }

    @Override
    public void onClick(View v) {

        // Sequencia do que fazer quando um botão é pressionado:
        //      1 -> Pegar seu ID numérico.
        //      2 -> Converter o ID numérico para seu nome em String.
        //      3 -> Pega o ultimo valor do seu nome, que sempre será o numero referente ao botão.
        //      4 -> Verificar se aquele botão pode ser pressisonado.
        //      5 -> Atualizar o quadro e colocar o numero referente ao jogador naquela posicao.
        //          5.1 -> Colocar o sinal do jogador no botão que foi pressionado.
        //      6 -> Verificar se houve empate.
        //          6.1 -> Caso sim, reiniciar o jogo.
        //      7 -> Verificar se houve vitória.
        //          7.1 -> Caso sim, atualizar o placar e reiniciar o jogo.
        //      8 -> Trocar os jogadores.
        //          8.1 -> Atualizar o placar para alterar a TextView que exibe qual o jogador atual.

        // 1
        int ID_botaoPressionado = v.getId();

        // 2
        String botaoPressionado = getResources().getResourceEntryName(ID_botaoPressionado);
        Log.d("botaoPressionado", botaoPressionado);

        // 3
        int numeroBotaoPressionado = Integer.parseInt(botaoPressionado.substring((botaoPressionado.length() - 1)));

        // 4
        if (quadro[numeroBotaoPressionado] != 0) {
            Log.d("msg", "Botao Ja Pressionado!");
            return;
        }

        // 5
        quadro[numeroBotaoPressionado] = jogadorAtual;
        if (jogadorAtual == 1) {
            // 5.1 -> X
            ((Button) v).setText("X");
            ((Button) v).setTextColor(Color.parseColor("#FFC34A"));
        } else {
            // 5.1 -> O
            ((Button) v).setText("O");
            ((Button) v).setTextColor(Color.parseColor("#70FFEA"));
        }

        // 6
        if (verificarEmpate() == 1) {
            Toast.makeText(this, "Empate!", Toast.LENGTH_SHORT).show();
            reiniciarJogo();
            return;
        };

        // 7
        if (verificarVitoria(jogadorAtual) == 1) {
            if (jogadorAtual == 1) {
                // X
                Toast.makeText(this, "Vitória do X", Toast.LENGTH_SHORT).show();
                placarX++;
            } else {
                // O
                Toast.makeText(this, "Vitória do O", Toast.LENGTH_SHORT).show();
                placarO++;
            }
            atualizarPlacar();
            reiniciarJogo();
        };

        // 8
        if (jogadorAtual == 1) {
            jogadorAtual = 2;
        } else {
            jogadorAtual = 1;
        }
        atualizarPlacar();
    }

    protected int verificarVitoria(int jogAtual) {
        // Retornar 1 = ganhou
        // Retornar 0 = não ganhou

        int a=0;

        // Verificar linhas
        if (quadro[0] == jogAtual && quadro[1] == jogAtual && quadro[2] == jogAtual) {return 1;}
        if (quadro[3] == jogAtual && quadro[4] == jogAtual && quadro[5] == jogAtual) {return 1;}
        if (quadro[6] == jogAtual && quadro[7] == jogAtual && quadro[8] == jogAtual) {return 1;}

        // Verificar Colunas
        if (quadro[0] == jogAtual && quadro[3] == jogAtual && quadro[6] == jogAtual) {return 1;}
        if (quadro[1] == jogAtual && quadro[4] == jogAtual && quadro[7] == jogAtual) {return 1;}
        if (quadro[2] == jogAtual && quadro[5] == jogAtual && quadro[8] == jogAtual) {return 1;}

        // Verificar diagonais
        if (quadro[0] == jogAtual && quadro[4] == jogAtual && quadro[8] == jogAtual) {return 1;}
        if (quadro[2] == jogAtual && quadro[4] == jogAtual && quadro[6] == jogAtual) {return 1;}

        return 0;
    }

    protected int verificarEmpate() {
        // Retornar 0 = não houve empate
        // Retornar 1 = houve empate

        for (int a=0; a<9; a++) {
            if (quadro[a] == 0) {
                return 0;
            }
        }
        return 1;
    }

    protected void reiniciarJogo() {
        quadro = new int[]{0,0,0,0,0,0,0,0,0};
        for (int a=0; a<9; a++) {
            buttons[a].setText("");
        }
    }
}